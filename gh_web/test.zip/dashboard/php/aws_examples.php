<?php

/* 
	Various AWS test scripts to retreive information from 
	S3 bucket
*/

// get $s3Client
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/s3connect.php");

// Buckets and creation data
echo '<h2>buckets and creation date</h2>';
$result = $s3Client->listBuckets();
foreach ($result['Buckets'] as $bucket) {
    echo "{$bucket['Name']} - {$bucket['CreationDate']}\n";
}

// Objects in the bucket
echo '<h2>objects in the bucket</h2>';
$iterator = $s3Client->getIterator('ListObjects', array(
    'Bucket' => 'uthillai'
));

foreach ($iterator as $object) {
    // echo $object['Key'] . "<br/>";
}

// Get first URL for a photo in a bucket 
// example 11/11-20161130053938-809949-000-256.jpg

$folder = '13/'; 

echo '<h2>first 256px object in bucket</h2>';
$iterator = $s3Client->getIterator('ListObjects', array(
    'Bucket' => 'rai-objects',
	'Prefix' => $folder
));

$i = 0;
foreach ($iterator as $object) {
	
	if ($i < 1) {
		
		$pos1 = 1+strrpos($object['Key'] , '-');
		$pos2 = strrpos($object['Key'] , '.' );
		$startIndex = min($pos1, $pos2);
		$length = abs($pos1 - $pos2);
		$size = substr($object['Key'], $startIndex, $length);
		if ($size == 256) {
			echo $object['Key'].'<br />';
			echo '<img src="https://s3-us-west-1.amazonaws.com/rai-objects/'.$object['Key'].'"/>';
			$i++;
		}
	}
	
}



// Upload a photo  

$bucket = 'uthillai';
$filepath = '../images/logo.png';
try {
    $result = $s3Client->putObject(array(
        'Bucket' => $bucket,
        'Key'    => 'temp/sample.png',
        'SourceFile'   => $filepath,
        'ACL'    => 'public-read'
    ));
    echo '<p>'.$result['ObjectURL'] . "</p>";
} catch (S3Exception $e) {
    echo $e->getMessage() . "\n";
}


// get images with -256 at the end 

$folder = $object_id.'/POS/TRN/'; 
$iterator = $s3Client->getIterator('ListObjects', array(
	'Bucket' => 'rai-objects',
	'Prefix' => $folder
));
foreach ($iterator as $object) {
	
	$pos1 = 1+strrpos($object['Key'] , '-');
	$pos2 = strrpos($object['Key'] , '.' );
	$startIndex = min($pos1, $pos2);
	$length = abs($pos1 - $pos2);
	$size = substr($object['Key'], $startIndex, $length);
	if ($size == 256) {
			if ($i == 1) { $imagearray .= '{'; }
			$imagearray .= '"col'.$i.'":"'.$object['Key'].'"';
			$i++;
			if ($i <= 10) {
				$imagearray .= ',';
			} else {
				$imagearray .= '},';
				$i = 1; 
			}
	}
}



?>