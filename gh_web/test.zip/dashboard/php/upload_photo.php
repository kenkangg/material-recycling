<?php 
/* 
	add a photo to S3 bucket 
*/ 

$object_id = $_POST['object_id'];
$bucket = 'uthillai';

// include functions used
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/getS3upload.php");
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/getPhotoerror.php");
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/getJPGpng.php");
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/getResized.php");

// make sure object_id was received 
if (!$object_id) {
	$error_message = 'uthillai error: no object_id post detected';
	echo $error_message.'<br>';
    exit();
}

// information about uploaded image 
$filename = $_FILES["image"]["name"]; // filename
$tmp_name = $_FILES["image"]["tmp_name"]; // file in php tmp folder
$fileErrorMsg = $_FILES["image"]["error"]; // 0 for false... and 1 for true

// a file was uploaded 
if (!$tmp_name) { 
    echo "<p>objectform_upload.php error: no photo was selected</p>";
    exit();
} 

// if there is a server error
if ($fileErrorMsg == 1) { 
    echo "<p>objectform_upload.php error: occured while uploading the image<p>";
    unlink($tmp_name); 
    exit();
}
		
// get photo errors on size, type
$error_message = getPhotoerror($tmp_name);
if ($error_message != 'none') {
	echo $filename.' unlinked on s3store due to '.$error_message.'<br>';
	unlink($tmp_name);	
	exit();
} 

// convert PNG to JPG
list($width, $height, $type) = getimagesize($tmp_name); 
$extension = 'jpg';
if ($type == 3) {
	$tmp_name = getJPGpng($tmp_name);
}

// if no image error, so upload various sizes to S3 
if ($error_message == 'none') {
	$imageonS3 = getS3upload($bucket, $tmp_name, $object_id, $width, $height, $extension);
}

// return the image name on S3 if upload was successful 
if ($error_message == 'none') {
	echo $imageonS3;
} else {
	echo $error_message;
}
	
?> 