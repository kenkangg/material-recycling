<?

/*
	This dumps an array of image urls given the object_id
	it is used for the view of object images in dataTables,
	the view all images button on the objectedit.php 
*/

include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/s3connect.php");

$object_id = $_GET['object_id'];
$i = 1;
$imagearray = '{ "data": [';

$folder = $object_id.'/POS/TRN/'; 
$iterator = $s3Client->getIterator('ListObjects', array(
	'Bucket' => 'uthillai',
	'Prefix' => $folder
));
foreach ($iterator as $object) {
	if ($i == 1) { $imagearray .= '{'; }
	$imagearray .= '"col'.$i.'":"'.$object['Key'].'"';
	$i++;
	if ($i <= 10) {
		$imagearray .= ',';
	} else {
		$imagearray .= '},';
		$i = 1; 
	}
}

$imagearray = rtrim($imagearray,'},');
$imagearray.= "}]}";

echo $imagearray;

?>

