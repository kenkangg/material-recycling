<?php

/*
	Deletes photos from S3 given the photo_stamp 
*/

// get the photo_stamp

$photo_set = $_POST['photo_set'];

// get object information
$object_id = strstr($photo_set, '-', true);
$photo_stamp = substr($photo_set, strpos($photo_set, "-") + 1); 
$bucket = 'uthillai';

// add 1 to the metric / gridtag_notkeep column
// means object was not correct when sent to gridtag 
require('../ssi/db_mysqli.php'); 
$thedate = date('Y-m-d');
$result = $conn->query("SELECT thedate FROM metric WHERE thedate = '$thedate' AND gridtag_notkeep > 0");
if($result->num_rows == 0) {
	// first entry of this date 
    $sql="INSERT INTO metric (metric_id, thedate, gridtag_keep, gridtag_notkeep) 
    VALUES ('', '$thedate', 0, 1)";
} else {
    $sql = "UPDATE metric SET gridtag_notkeep = gridtag_notkeep + 1 WHERE thedate = '$thedate'";
}
$conn->query($sql); 
$conn->close();

// connect to S3 to get client
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/s3connect.php");

// delete the photos from the SPT folders

$prefix = $object_id.'/SPT/TRN/'.$photo_stamp;
$s3Client->deleteMatchingObjects($bucket, $prefix);
	
$prefix2 = $object_id.'/SPT/ORG/'.$photo_stamp;
$s3Client->deleteMatchingObjects($bucket, $prefix2);	
	
?>