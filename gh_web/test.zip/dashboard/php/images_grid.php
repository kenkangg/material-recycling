<?php 

/*
	get photos needed for match tag 
*/


// get the object_id 
$object_id = $_GET['object_id'];

// get $s3Client
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/s3connect.php");
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/getPhotostamp.php");
include($_SERVER['DOCUMENT_ROOT']."/dashboard/ssi/db_mysqli.php");

// write the page title
$sql="SELECT * from object where object_id = '$object_id'";
$rs=$conn->query($sql);
while($row = $rs->fetch_assoc()) {
	$object_id= $row["object_id"];
	$bin = $row["bin"];	
	$material = $row["material"];
	$object_type = $row["object_type"];	
	$level1 = $row["level1"];	
	$level2 = $row["level2"];	
	$level3 = $row["level3"];	
	$level4 = $row["level4"];	
	$sku = $row["sku"];	
} 
echo '<div class="title">'.$object_id.' '.$bin.' '.$material.' '.$object_type.' '.$level1.' '.$level2.' '.$level3.' '.$level4.' '.$sku.'</div>';


// write the photos 

echo '<div class="thephotos">';

$folder = $object_id.'/POS/TRN/';

$iterator = $s3Client->getIterator('ListObjects', array(
    'Bucket' => 'uthillai',
    'Prefix' => $folder
));
foreach ($iterator as $object) {
	$photo_id = $object['Key'];
	$photo_stamp = getPhotostamp($photo_id);
	echo '<a href="#"/>';
	echo '<img src="https://s3-us-west-1.amazonaws.com/uthillai/'.$photo_id.'" class="keepthis" id="'.$object_id.'-'.$photo_stamp.'"/>';
	echo '</a>';
}

echo '</div>';



?>


