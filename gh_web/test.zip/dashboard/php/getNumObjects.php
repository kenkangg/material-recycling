<?php

/* 
	Get the number of photos in /0 speedtag folder 
*/

// get $s3Client
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/s3connect.php");

// get the paths 
$server = 'https://s3-us-west-1.amazonaws.com/uthillai/';
$bucket = 'uthillai';
$folder = '0/SPT/ORG/';

$numobjects = 0;
$objects = $s3Client->getIterator('ListObjects', array(
    "Bucket" => $bucket,
    "Prefix" => $folder
));
foreach ($objects as $object) {
    $numobjects++;
}

echo $numobjects;




	