<?php 

/*
	get photos needed for gridtag 
*/

// get $s3Client
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/s3connect.php");

// function to convert long photo_id to photo_stamp
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/getPhotostamp.php");

// get all the SPT/TRN images in /0 Speedtag folder 


$iterator = $s3Client->getIterator('ListObjects', array(
    'Bucket' => 'uthillai',
    'Prefix' => '0/SPT/ORG/'
));

foreach ($iterator as $object) {
	$photo_id = $object['Key'];

	// get the Photoset
	$photo_stamp = getPhotostamp($photo_id);
	
	// show 256 px images 
	echo '<a href=""/><img src="https://s3-us-west-1.amazonaws.com/uthillai/'.$photo_id.'" class="stthis" id="'.'0-'.$photo_stamp.'"/></a>';

	// echo $photo_id.'<br>'; // do something 
}




			

?>


