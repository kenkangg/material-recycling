<?php
/*
	This deletes the object from the database and photos from S3
*/

include ('../ssi/db_mysqli.php');

// get the item to delete
$object_id = $_POST['object_id'];

// delete the data row
$sql="DELETE FROM object WHERE object_id ='$object_id' LIMIT 1";
$conn->query($sql); 

// get $s3Client
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/s3connect.php");

// delete object ids 
$bucket = 'uthillai';

// delete the photos in all object folders
$keyname = $object_id.'/';
$s3Client->deleteMatchingObjects($bucket, $keyname);


?>