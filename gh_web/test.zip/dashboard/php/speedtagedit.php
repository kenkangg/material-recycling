<?php

require('../ssi/db_mysqli.php'); 

// hidden input form the form
$photo_url = $_POST["photo_url"];
$object_id = $_POST["object_id"];

// $object_id = 121;
// $photo_url = 'https://s3-us-west-1.amazonaws.com/rai-objects/0/SPT/ORG/20170306190512-100228-512.jpg';
// Example: 
// photo_url = https://s3-us-west-1.amazonaws.com/rai-objects/0/SPT/ORG/20161220025340-486104-391.jpg 
// phototail_org is 20161220025340-486104-391.jpg 
// phototail_256 is 20161220025340-486104
$phototail_org = substr($photo_url, strpos($photo_url, "ORG/") + 4);    
$pos2 = strrpos($phototail_org , '-' );
$phototail_256 = substr($phototail_org, 0, $pos2);

// echo $phototail_256;

// add 1 to the metric / gridtag_notkeep column
require('../ssi/db_mysqli.php'); 
$thedate = date("Y-m-d");
$result = $conn->query("SELECT * FROM metric WHERE thedate = '$thedate'");
if($result->num_rows == 0) {
	// first entry of this date 
	$sql="INSERT INTO metric (metric_id, thedate, gridtag_keep, gridtag_notkeep) 
    VALUES ('', '$thedate', 0, 1)";
    $conn->query($sql); 
} else {
	// add to gridtag_keep
    $sql = "UPDATE metric SET gridtag_notkeep = gridtag_notkeep + 1 WHERE thedate = '$thedate'";
    $conn->query($sql); 
}
$conn->close();

// move the images with the current photoset to a new object folder 
$bucket = 'uthllai';                                       //CHANGES MADE HERE, ORIGINALLY: rai-objects

// connect to S3 to get client
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/s3connect.php");

// move 256 photo from 0/ to new object id 
$prefix =  '0/SPT/TRN/'.$phototail_256;
$iterator = $s3Client->getIterator('ListObjects', array(
	'Bucket' => $bucket,
	'Prefix' => $prefix
));
foreach ($iterator as $object) {
	
	$sourceKeyname = $object['Key'];
	$targetKeyname = str_replace("0/SPT/", $object_id.'/POS/', $sourceKeyname);
	
	// Copy from SPT to POS
	$s3Client->copyObject(array(
		'Bucket'     => $bucket,
		'Key'        => $targetKeyname,
		'CopySource' => "{$bucket}/{$sourceKeyname}",
		'StorageClass' => 'REDUCED_REDUNDANCY',
		'ACL'    => 'public-read'
	));

	// then delete the SPT one 
	$s3Client->deleteObject(array(
		'Bucket' => $bucket,
		'Key'    => $sourceKeyname
	));	
	
}	

// now do the same for the larger image 
$prefix2 = '0/SPT/ORG/'.$phototail_org;
$iterator = $s3Client->getIterator('ListObjects', array(
	'Bucket' => $bucket,
	'Prefix' => $prefix2
));
foreach ($iterator as $object) {
	
	$sourceKeyname = $object['Key'];
	$targetKeyname = str_replace("0/SPT/", $object_id.'/POS/', $sourceKeyname);
	
	// Copy from SPT to POS
	$s3Client->copyObject(array(
		'Bucket'     => $bucket,
		'Key'        => $targetKeyname,
		'CopySource' => "{$bucket}/{$sourceKeyname}",
		'StorageClass' => 'REDUCED_REDUNDANCY',
		'ACL'    => 'public-read'
	));

	// then delete the SPT one 
	$s3Client->deleteObject(array(
		'Bucket' => $bucket,
		'Key'    => $sourceKeyname
	));	
	
}	


?>
