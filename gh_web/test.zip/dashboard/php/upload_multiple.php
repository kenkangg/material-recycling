<?php
/*
	upload images to S3 placed in directory s3store folder 
*/

$object_id = $_POST['object_id'];

// include functions used
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/getS3upload.php");
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/getPhotoerror.php");
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/getJPGpng.php");
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/getResized.php");

// make sure object_id was received 
if (!$object_id) {
	$error_message = 'uthillai error: no object_id post detected';
	echo $error_message.'<br>';
    exit();
}

// get rid of unwanted files like .DS_store
$unwanted_filenames = array('.DS_Store','.localized','Thumbs.db','error_log');
$it = new RecursiveDirectoryIterator("../s3store/");  
foreach(new RecursiveIteratorIterator($it) as $file) {
    if (in_array(basename($file), $unwanted_filenames)) {
        unlink($file);  
    }
}

// check that there are files in S3
$directory = "../s3store/";
$files = glob($directory . "*");
$filecount = count($files);

if ($filecount != 0) {
	for ($i = 1; $i <= $filecount; $i++) {
				
		// get the next filename  
		$directory = "../s3store/";
		$files = scandir ($directory);
		$filename = '../s3store/'.$files[2];
		
		// get photo errors on size, type
		$error_message = getPhotoerror($filename);
		if ($error_message != 'none') {
			echo $filename.' unlinked on s3store due to '.$error_message.'<br>';
			unlink($filename);	
		} 
		
		// convert PNG to JPG
		list($width, $height, $type) = getimagesize($filename); 
		$extension = 'jpg';
		if ($type == 3) {
			$temp = getJPGpng($filename);
			unlink($filename);
			$filename = $temp;
		}
		
		// no image error, so upload various sizes to S3 
		if ($error_message == 'none') {
			$bucket = 'uthillai';
			getS3upload($bucket, $filename, $object_id, $width, $height, $extension);
		}

		// remove the image from s3store
		unlink($filename);
	}
}

echo $filecount;

?> 
