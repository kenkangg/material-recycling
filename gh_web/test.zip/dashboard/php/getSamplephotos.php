<?php

/*
	Run this only if needed 
	It gets the first 256px photo for each object in S3
	stores it in the s3Store/images folder 
*/

// get $s3Client
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/s3connect.php");
   	  
// conncec to the database
include '../ssi/db_mysqli.php'; 

$server = 'https://s3-us-west-1.amazonaws.com/uthillai/';
$bucket = 'uthillai';   

$sql="SELECT * from object";
$rs=$conn->query($sql);
while($row = $rs->fetch_assoc()) {
	$object_id = $row["object_id"];	
	
	// get first image from S3
	// get the paths 
	
	$folder = $object_id.'/POS/TRN/';

	$response = $s3Client->listObjects(array(
		'Bucket' => $bucket, 
		'MaxKeys' => 1, 
		'Prefix' => $folder
	));

	$count = count($response);

	// hack - I'm not sure yet how to count a bucket/folder in S3
	// it seems an empty folder returns 7 

	if ($count > 7) {
		$files = $response->getPath('Contents');
		$request_id = array();
		foreach ($files as $file) {
	   	 	
	   	 	// the image on S3
	   	 	$photo_id = $file['Key'];
	   	 	$urlname = $server.$photo_id;

	   	 	// copy it to local folder 
	   	 	copy($urlname, '../s3store/images/'.$object_id.'.jpg');

		}
	} 

	echo $object_id.'<br>';

}



 
		
?>