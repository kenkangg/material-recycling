<?php

/*
	Deletes photos from S3 given the photo_stamp 
*/

// get the photo_stamp

$photo_set = $_POST['photo_set'];

// get object information
$object_id = strstr($photo_set, '-', true);
$photo_stamp = substr($photo_set, strpos($photo_set, "-") + 1); 
$bucket = 'uthillai';

// connect to S3 to get client
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/s3connect.php");

// delete the photos from the SPT folders

$prefix = $object_id.'/POS/TRN/'.$photo_stamp;
$s3Client->deleteMatchingObjects($bucket, $prefix);
	
$prefix2 = $object_id.'/POS/ORG/'.$photo_stamp;
$s3Client->deleteMatchingObjects($bucket, $prefix2);	
	
?>