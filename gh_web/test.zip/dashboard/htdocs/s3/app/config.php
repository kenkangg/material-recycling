<?php
return [
	's3' => [
		'key' => 'AKIAI6BSDJOAYI5JR4PA',
		'secret' => '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',
		'bucket' => 'uthillai'


];