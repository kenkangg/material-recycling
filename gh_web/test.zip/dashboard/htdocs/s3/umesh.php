<?php
// Include the SDK using the Composer autoloader
//require 'vendor/autoload.php';
require "C:/xampp/phpMyAdmin/vendor/autoload.php";
use Aws\S3\S3Client;
use Aws\S3\Exception\S3Exception;

$s3 = new Aws\S3\S3Client([
    'version' => 'latest',
    'region'  => 'us-east-1'
])
//echo "Umesh php code";
?>