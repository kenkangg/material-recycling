<?php

// connect to database

$DBServer = 'JARVIS'; // 192.95.31.34'; 
$DBUser   = 'root'; // 'rai'
$DBPass   =  'M$94A7b!L';// 'Apricot1olo!';
$DBName   = 'recycle'; // 'recyle-ai'

$conn = new mysqli($DBServer, $DBUser, $DBPass, $DBName);
 
if ($conn->connect_error) {
  trigger_error('Database connection failed: '  . $conn->connect_error, E_USER_ERROR);
  echo "error"; 
} 

?>

