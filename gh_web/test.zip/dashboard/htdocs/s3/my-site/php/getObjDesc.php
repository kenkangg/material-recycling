<?php 
/*
	given object_id, outputs the object description  
*/

$object_id=$_POST['object_id'];

require('../ssi/db_mysqli.php'); 

$sql="SELECT * from object where object_id = '$object_id'";
$rs=$conn->query($sql);
while($row = $rs->fetch_assoc()) {
	$object_id = $row["object_id"];
	$bin = $row["bin"];	
	$material = $row["material"];	
	$object_type = $row["object_type"];	
	$level1 = $row["level1"];	
	$level2 = $row["level2"];	
	$level3 = $row["level3"];	
	$level4 = $row["level4"];	
	$sku= $row["sku"];
}

$name = $object_id.' '.$bin.' '.$material.' '.$object_type.' '.$level1.' '.$level2.' '.$level3.' '.$level4.' '.$sku;
echo $name;

?>