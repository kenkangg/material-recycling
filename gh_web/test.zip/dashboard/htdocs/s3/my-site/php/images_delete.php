<?php

/*
	delete a POS image pair from S3 from images.html (image view)
	photo_id example 81/POS/TRN/20161227044847-487912-256.jpg
*/

// get the photo_stamp
$photo_id = $_GET['photo_id'];

// get the photo_stamp
include 'getPhotostamp.php';
$photo_stamp = getPhotostamp($photo_id); 

echo $photo_stamp.'<br>';

// get object_id from photo_id
$object_id = strtok($photo_id, '/');

echo $object_id.'<br>';

$photo_org = $object_id.'/POS/ORG/'.$photo_stamp.'-ORG.jpg';

echo $photo_org;

/*

// connect to S3 bucket to get client
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/s3connect.php");
$bucket = 'rai-objects';

// delete the TRN image
$s3Client->deleteMatchingObjects($bucket, $photo_id);
	
// delete the ORG image 
$s3Client->deleteMatchingObjects($bucket, $photo_org);

*/


?>

