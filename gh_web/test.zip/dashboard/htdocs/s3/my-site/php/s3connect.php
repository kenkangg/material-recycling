<?php

/*	
	Key include that connect to AWD S3
	using PHP SDK 
*/
require "C:/xampp/phpMyAdmin/vendor/autoload.php";
//include($_SERVER['DOCUMENT_ROOT']."/vendor/autoload.php");

// create a client
use Aws\S3\S3Client;
use Aws\S3\Exception\S3Exception;

$s3Client = new S3Client([
    'version'     => 'latest',
    'region'      => 'us-west-1',
    'credentials' => [
 		'key'    => 'AKIAJRISJNZFD22OVNQA',
        'secret' => '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' 
    ],
]);
?>

