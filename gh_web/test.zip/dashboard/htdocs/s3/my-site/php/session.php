<?php 
session_start();

if (isset($_SESSION['check'])) {

	if ($_SESSION['check'] == 'login') {
		echo $_SESSION['check'];
	} 

}


?>
