<?php

/*
	output of object database for improving class labels 
	{"19":"19 compost banana etc", }
*/

require('../ssi/db_mysqli.php'); 

$d1 = '{';

$sql="SELECT * from object";
$rs=$conn->query($sql);
while($row = $rs->fetch_assoc()) {
	$object_id = $row["object_id"];
	$bin = $row["bin"];	
	$material = $row["material"];	
	$object_type = $row["object_type"];	
	$level1 = $row["level1"];	
	$level2 = $row["level2"];	
	$level3 = $row["level3"];	
	$level4 = $row["level4"];	
	$sku= $row["sku"];

	$d1 .= '"'.$object_id.'":"'.$object_id.' '.$bin.' '.$material.' '.$object_type.' '.$level1.' '.$level2.' '.$level3.' '.$level4.'",';
}
	$d1 = rtrim($d1,',');
	$d1 .= '}';
	echo $d1;

?>