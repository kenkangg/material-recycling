<?php

/*
	gets search results for speedtag.html 
*/

include '../ssi/db_mysqli.php'; 

$query = $_GET['query'];

$indquery = explode(" ", $query);
$count = str_word_count($query);

$fullquery = "SELECT * FROM object WHERE CONCAT(' ',bin, material, object_type, level1, level2, level3, level4, sku) LIKE '%{$indquery[0]}%'";

for ($x = 1; $x < $count; $x++) {
    $fullquery = $fullquery." AND CONCAT(' ',bin, material, object_type, level1, level2, level3, level4, sku) LIKE '%{$indquery[$x]}%'";
} 

$result = $conn->query($fullquery);
    while ($row = $result->fetch_object()){ $object[] = $row->object_id.'- <img src="../s3store/images/'.$row->object_id.'.jpg"/>'.$row->bin.' '.$row->material.' '.$row->object_type.' '.$row->level1.' '.$row->level2.' '.$row->level3.' '.$row->level4.' '.$row->sku;
	// while ($row = $result->fetch_object()){ $object[] = $row->object_id.'- '.$row->bin.' '.$row->material.' '.$row->object_type.' '.$row->level1.' '.$row->level2.' '.$row->level3.' '.$row->level4.' '.$row->sku;
	}
    $result->close();

     // array_unshift($object, "add new object");
     echo json_encode($object);

?>
		