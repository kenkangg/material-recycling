<?php

/*
	output of object database in JSON array 
	to be used for object table 
*/

require('../ssi/db_mysqli.php'); 

$objectArray = array();
$sql="SELECT * from object";
$rs=$conn->query($sql);
while($row = $rs->fetch_array(MYSQL_ASSOC)) {
	$objectArray[] = $row;
}

// add the data heaader for dataTables 
echo '{ "data": '.json_encode($objectArray).'}';



?>