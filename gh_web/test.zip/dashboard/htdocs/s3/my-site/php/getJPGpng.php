<?php 
/*
	converts PNG to JPG 
*/

function getJPGpng($filename) {
	$outputFile = $_SERVER['DOCUMENT_ROOT']."/dashboard/s3store/convpng.jpg";
	// $outputFile = '../s3store/convjpg.jpg'; 
	$image = imagecreatefrompng($filename);
	imagejpeg($image, $outputFile, 100);
	// unlink is done later 
	// unlink($image);
	return $outputFile;
}
