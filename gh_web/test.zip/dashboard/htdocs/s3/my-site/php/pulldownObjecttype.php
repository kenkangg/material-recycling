<?php 

/*
	Outputs options for pulldown form 
*/

require('../ssi/db_mysqli.php'); 

$sql="SELECT DISTINCT(object_type) as object_type from object ORDER BY object_type asc";
$rs=$conn->query($sql);
while ($row = $rs->fetch_object()) { 
	$object_type = $row->object_type;
	if ($object_type != '') {
		echo '<option value="'.$object_type.'">'.$object_type.'</option>';
	}
}

?>
