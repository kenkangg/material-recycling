<?php 

/*
	get photos needed for gridtag 
*/

// get $s3Client
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/s3connect.php");
include($_SERVER['DOCUMENT_ROOT']."/dashboard/ssi/db_mysqli.php");

// function to convert long photo_id to photo_stamp
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/getPhotostamp.php");

$object_id = 0;

// find the first object_id that needs SPT review 
// (not POS images)
$iterator = $s3Client->getIterator('ListObjects', array(
    'Bucket' => 'rai-objects',
    'Delimiter' => 'POS' 
));
foreach ($iterator as $object) {
	$photo_id = $object['Key'];
	$object_id = strtok($photo_id, '/');
	// ignore object_id 0 which is for speedtag  
	if ($object_id != '0') {
		break;
	}	
}

// no objects needing SPT are found 
if ($object_id == 0 or empty($object_id)) {
	echo '<div class="titletemp">done!</div>';
	exit();
}

// title the object to be worked on 
$sql="SELECT * from object where object_id = '$object_id'";
$rs=$conn->query($sql);
while($row = $rs->fetch_assoc()) {
	$object_id= $row["object_id"];
	$bin = $row["bin"];	
	$material = $row["material"];
	$object_type = $row["object_type"];	
	$level1 = $row["level1"];	
	$level2 = $row["level2"];	
	$level3 = $row["level3"];	
	$level4 = $row["level4"];	
	$sku = $row["sku"];	
} 
echo '<div class="titletemp">'.$object_id.' '.$bin.' '.$material.' '.$object_type.' '.$level1.' '.$level2.' '.$level3.' '.$level4.' '.$sku.'</div>';


// get all the SPT/TRN images in the first encountered folder 

echo '<div class="goodphotos">';

$iterator = $s3Client->getIterator('ListObjects', array(
    'Bucket' => 'rai-objects',
    'Delimiter' => 'ORG',
    'Prefix' => $object_id.'/SPT/TRN/'
));

foreach ($iterator as $object) {
	$photo_id = $object['Key'];

	// get the Photoset
	$photo_stamp = getPhotostamp($photo_id);
	
	// show 256 px images 
	echo '<a href=""/><img src="https://s3-us-west-1.amazonaws.com/rai-objects/'.$photo_id.'" class="keepthis" id="'.$object_id.'-'.$photo_stamp.'"/></a>';

	// echo $photo_id.'<br>'; // do something 
}

echo '</div>';


			

?>


