<?php

/* 
	Get first image in 0 Speedtag folder 
*/

// get $s3Client
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/s3connect.php");


// get the paths 
$server = 'https://s3-us-west-1.amazonaws.com/rai-objects/';
$bucket = 'rai-objects';

// start counting at 0 
$trn = 0;
$org = 0;

// loop through all images 
$iterator = $s3Client->getIterator('ListObjects', array(
    'Bucket' => 'rai-objects'
));

foreach ($iterator as $object) {
	if (strpos($object['Key'], "/TRN/") !== false) { 
    	$trn++;
	}
	if (strpos($object['Key'], "/ORG/") !== false) { 
    	$org++;
	}
}

echo 'TRN training: '.$trn.'<br>';
echo 'ORG original: '.$org.'<br>';

?>



