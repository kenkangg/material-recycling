<?php 

include ("../ssi/db_mysqli.php");

$task_id = $_POST['task_id'];	

$sql="DELETE FROM task WHERE task_id = '$task_id'";
$conn->query($sql); 

?>
