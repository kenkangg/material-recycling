<?php

/* 
	Get first image in bucket given object_id test
*/

// get $s3Client
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/s3connect.php");

// get the object_id
$object_id = $_POST['object_id'];

// get the paths 
$server = 'https://s3-us-west-1.amazonaws.com/rai-objects/';
$bucket = 'rai-objects';
$folder = $object_id.'/POS/TRN/';

// to get the first file name, I have to skip
// skip the first key[0] (ex. 23/POS/) to get to the filename 
$response = $s3Client->listObjects(array(
	'Bucket' => $bucket, 
	'MaxKeys' => 1, 
	'Prefix' => $folder
));

$count = count($response);

// hack - I'm not sure yet how to count a bucket/folder in S3
// it seems an empty folder returns 7 

if ($count > 7) {
	$files = $response->getPath('Contents');
	$request_id = array();
	foreach ($files as $file) {
   	 	$filename = $file['Key'];
	}
} else {
	$server = '';
	$filename = "../images/noimages.png";
} 

echo $server.$filename;


