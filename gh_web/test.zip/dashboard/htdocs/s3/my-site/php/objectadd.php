<?php 

require('../ssi/db_mysqli.php'); 

$bin = $_POST["bin"];
$material = htmlentities($_POST["material"], ENT_QUOTES, 'UTF-8');
$object_type = htmlentities($_POST["object_type"], ENT_QUOTES, 'UTF-8');
$level1 = htmlentities($_POST["level1"], ENT_QUOTES, 'UTF-8');
$level2 = htmlentities($_POST["level2"], ENT_QUOTES, 'UTF-8');
$level3 = htmlentities($_POST["level3"], ENT_QUOTES, 'UTF-8');
$level4 = htmlentities($_POST["level4"], ENT_QUOTES, 'UTF-8');
$sku = $_POST["sku"];

// deal with the inputs on the object form 
if (!empty($_POST['bininput'])) {
	$bin = $_POST['bininput'];
}

if (!empty($_POST['materialinput'])) {
	$material = htmlentities($_POST['materialinput'], ENT_QUOTES, 'UTF-8');
}

if (!empty($_POST['object_typeinput'])) {
	$object_type = htmlentities($_POST['object_typeinput'], ENT_QUOTES, 'UTF-8');
}

// string to lower case 
$bin = strtolower($bin);
$material = strtolower($material);
$object_type = strtolower($object_type);
$level1 = strtolower($level1);
$level2 = strtolower($level2);
$level3 = strtolower($level3);
$level4 = strtolower($level4);
$sku = strtolower($sku);

$sql="INSERT INTO object (object_id, bin, material, object_type, level1, level2, level3, level4, sku) 
VALUES ('', '$bin', '$material', '$object_type', '$level1', '$level2', '$level3', '$level4', '$sku')";
$conn->query($sql); 

?>
