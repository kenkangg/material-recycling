<?php 

/*
	uploads image to S3
	includes re-sizing to 256, 1200 
*/

function getS3upload($bucket, $filename, $object_id, $width, $height, $extension) {
		
	// filename should be on this server 
	// passed in as = '../s3store/temp.jpg'
		
	// start with no error 
	$error_message = 'none';
				
	// for creating unique file names 
	date_default_timezone_set('America/Los_Angeles'); 
	$photo_stamp = date("Ymdhis").'-'.rand(100000,999999);
	$maxdim = max($width, $height);
	
	// create filenames for S3
	$filenameorg = $photo_stamp.'-'.$maxdim.'.jpg';
	$filename256 = $photo_stamp.'-256.jpg';
	$filename1200 = $photo_stamp.'-1200.jpg';
	
	// create foldernames for S3, go straight to accepted POS/ 
	$foldername256 = $object_id.'/POS/TRN/';
	$foldername1200 = $object_id.'/POS/ORG/';
	
	// create folder path on host server
	// these will be unlink deleted after use  
	// $tmp_file_path = "../s3store/".$filenameorg;
	$tmp_file_path256 = "../s3store/".$filename256;
	$tmp_file_path1200 = "../s3store/".$filename1200;
	
	// resize the original image
	if ($width >= 256 || $height >= 256) {
		// Resize the image to 256px
		$target_file = $filename;
		$resized_file = $tmp_file_path256;
		$wmax = 256;
		$hmax = 256;
		ak_img_resize($target_file, $resized_file, $wmax, $hmax, $extension);
	}
		
	if ($width > 1200 || $height > 1200) {
		// Resize the image to 1200px
		$target_file = $filename;
		$resized_file = $tmp_file_path1200;
		$wmax = 1200;
		$hmax = 1200;
		ak_img_resize($target_file, $resized_file, $wmax, $hmax, $extension);
	}
	
	// get $s3Client
	include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/s3connect.php");
	
	// store 256px image
	if (file_exists($tmp_file_path256)) {
		try {
			$result = $s3Client->putObject(array(
				'Bucket' => $bucket,
				'Key'    => $foldername256.$filename256,
				'SourceFile'   => $tmp_file_path256,
				'StorageClass' => 'REDUCED_REDUNDANCY',
				'ACL'    => 'public-read'
			));
			} catch (S3Exception $e) {
				$error_message = $e->getMessage() . "\n";
			}
			unlink($tmp_file_path256);
	}
		
	// store 1200px image 
	if (file_exists($tmp_file_path1200)) {
		try {
			$result = $s3Client->putObject(array(
				'Bucket' => $bucket,
				'Key'    => $foldername1200.$filename1200,
				'SourceFile'   => $tmp_file_path1200,
				'StorageClass' => 'REDUCED_REDUNDANCY',
				'ACL'    => 'public-read'
			));
			} catch (S3Exception $e) {
				$error_message = $e->getMessage() . "\n";
			}
			unlink($tmp_file_path1200);
	}
	
	// store original image between 
	if ($maxdim >= 256 && $maxdim <= 1200) {
		try {
			$result = $s3Client->putObject(array(
				'Bucket' => $bucket,
				'Key'    => $foldername1200.$filenameorg,
				'SourceFile'   => $filename,
				'StorageClass' => 'REDUCED_REDUNDANCY',
				'ACL'    => 'public-read'
			));
			} catch (S3Exception $e) {
				$error_message = $e->getMessage() . "\n";
			}
	}
	
	// unlink($filename);
		
	// return $error_message;
	return $error_message; 
	
}

?> 
