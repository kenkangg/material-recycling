<?php

/* 
	Get size of rai-objects bucket
*/

// get $s3Client
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/s3connect.php");

// get the paths 
$server = 'https://s3-us-west-1.amazonaws.com/rai-objects/';
$bucket = 'rai-objects';

$size = 0;
$objects = $s3Client->getIterator('ListObjects', array(
        "Bucket" => $bucket,
        // "Prefix" => $folder
    ));
    $i = 0;
    foreach ($objects as $object) {
        $size = $size+$object['Size'];
    }

echo number_format($size);


?>



