<?php

/*
	output of object database in JSON array 
	to be used for object table 

	See file php/d3tree.php which generates JSON data for data/d3tree.json
*/

require('../ssi/db_mysqli.php'); 

$jsontree  =  '{';
$jsontree .= '"name": "trash",';
$jsontree .= '"children": [{';

$sql="SELECT DISTINCT(bin) from object ORDER BY bin;";
$rs=$conn->query($sql);
while($row = $rs->fetch_assoc()) {
	$bin = $row["bin"];	

	$jsontree .= '"name":"'.$bin.'",';
	$jsontree .= '"children": [{';

	$sql1="SELECT DISTINCT(material) from object where bin = '$bin' order by material";
	$rs1=$conn->query($sql1);
	while($row1 = $rs1->fetch_assoc()) {
		$material = $row1["material"];

		$jsontree .= '"name":"'.$material.'",';
		$jsontree .= '"children": [{';

		$sql2="SELECT DISTINCT(object_type) from object where bin = '$bin' and material = '$material' order by object_type asc";
		$rs2=$conn->query($sql2);
		while($row2 = $rs2->fetch_assoc()) {
				$object_type = $row2["object_type"];

			$jsontree .= '"name":"'.$object_type.'",';
			$jsontree .= '"children": [{';

				$sql3="SELECT * from object where bin = '$bin' and material = '$material' and object_type = '$object_type' order by level1 asc";
				$rs3=$conn->query($sql3);
				while($row3 = $rs3->fetch_assoc()) {
					$level1 = $row3["level1"];	
					$level2 = $row3["level2"];	
					$level3 = $row3["level3"];	
					$level4 = $row3["level4"];	
					$level = $level1.' '.$level2.' '.$level3.' '.$level4;

					$jsontree .= '"name":"'.$level.'"';
					$jsontree .= '}, {';

				}
				$jsontree = rtrim($jsontree, "}, {");
				$jsontree .= '}]';
				$jsontree .= '}, {';
		}
		$jsontree = rtrim($jsontree, "}, {");
		$jsontree .= '}]';
		$jsontree .= '}, {';
	}	
	$jsontree = rtrim($jsontree, "}, {");
	$jsontree .= '}]';
	$jsontree .= '}, {';
}
$jsontree = rtrim($jsontree, "}, {");
$jsontree .= '}]';

$jsontree .= '}';

echo $jsontree;


?>