<?php

/*
	Part of gridtag system
	Means an object was correct (positive) on gridtag 
	Add POS prefix to objects accepted with green box
*/

// get the photo_stamp
// ex 16-2016202040727-123534

$photo_set = $_POST['photo_set'];

// get object information
$object_id = strstr($photo_set, '-', true);
$photo_stamp = substr($photo_set, strpos($photo_set, "-") + 1); 
$bucket = 'rai-objects';

// add 1 to the metric / gridtag_keep column
require('../ssi/db_mysqli.php'); 
$thedate = date("Y-m-d");
$result = $conn->query("SELECT * FROM metric WHERE thedate = '$thedate'");
if($result->num_rows == 0) {
	// first entry of this date 
	$sql="INSERT INTO metric (metric_id, thedate, gridtag_keep, gridtag_notkeep) 
    VALUES ('', '$thedate', 1, 0)";
    $conn->query($sql); 

} else {
	// add to gridtag_keep
    $sql = "UPDATE metric SET gridtag_keep = gridtag_keep + 1 WHERE thedate = '$thedate'";
    $conn->query($sql); 
}
$conn->close();



// connect to S3 to get client
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/s3connect.php");

// get object array for each folder 
$prefix = $object_id.'/SPT/TRN/'.$photo_stamp;
$iterator = $s3Client->getIterator('ListObjects', array(
	'Bucket' => $bucket,
	'Prefix' => $prefix
));
foreach ($iterator as $object) {
	
	$sourceKeyname = $object['Key'];
	$targetKeyname = str_replace("SPT","POS", $sourceKeyname);
	
	echo $sourceKeyname.'<br>';
	echo $targetKeyname.'<br>';
	
	
	// Copy from SPT to POS
	$s3Client->copyObject(array(
		'Bucket'     => $bucket,
		'Key'        => $targetKeyname,
		'CopySource' => "{$bucket}/{$sourceKeyname}",
		'StorageClass' => 'REDUCED_REDUNDANCY',
		'ACL'    => 'public-read'
	));
	

	// then delete the SPT one 
	$s3Client->deleteObject(array(
		'Bucket' => $bucket,
		'Key'    => $sourceKeyname
	));	
	
}	


// now do the same for the larger image 
$prefix2 = $object_id.'/SPT/ORG/'.$photo_stamp;
$iterator = $s3Client->getIterator('ListObjects', array(
'Bucket' => $bucket,
'Prefix' => $prefix2
));
foreach ($iterator as $object) {
	
	$sourceKeyname = $object['Key'];
	$targetKeyname = str_replace("SPT","POS", $sourceKeyname);
	
	// Copy from SPT to POS
	$s3Client->copyObject(array(
		'Bucket'     => $bucket,
		'Key'        => $targetKeyname,
		'CopySource' => "{$bucket}/{$sourceKeyname}",
		'StorageClass' => 'REDUCED_REDUNDANCY',
		'ACL'    => 'public-read'
	));

	// then delete the SPT one 
	$s3Client->deleteObject(array(
		'Bucket' => $bucket,
		'Key'    => $sourceKeyname
	));	
	
}	

?>


