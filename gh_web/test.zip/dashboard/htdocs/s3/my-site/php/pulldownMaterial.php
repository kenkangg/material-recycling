<?php 

/*
	Outputs options for pulldown form
*/

require('../ssi/db_mysqli.php'); 


$sql="SELECT DISTINCT(material) as material from object ORDER BY material asc";
$rs=$conn->query($sql);
while ($row = $rs->fetch_object()) { 
	$material = $row->material;
	if ($material != '') {
		echo '<option value="'.$material.'">'.$material.'</option>';
	}
}

?>
