<?php 

/*
	given a $filename, checks for image errors
	extension, size, aspect ratio, 
	returns error message

*/

function getPhotoerror($filename) {
	
	$error_message = 'none';

	if (!@getimagesize($filename)) {
		
		//image does not exists
		$error_message = "getPhotoerror.php: failed on get image size";
	
	} else {
	
		// ok image exists, check next 
		list($width, $height, $type) = getimagesize($filename); 
		
			// type must be be 2 (jpg, jpeg) or 3 (png)
			if ($type != 2 && $type != 3) {
				 $error_message = "getPhotoerror.php: image is not .jpg, .jpeg, or .png ";
			} 
			
			// Don't except panoramic images
			if ((3*$width < $height) || (3*$height < $width)) {
				$error_message = "getPhotoerror.php: image is too wide or too tall";
			} 
			
			// make sure it is an image is large enough
			if ($width < 256 || $height < 256) {
				$error_message = "getPhotoerror.php: width or height is <256px";
			}
			
			// make sure it is an image is small enough
			if ($width > 3000 || $height > 3000) {
				$error_message = "getPhotoerror.php: image is too large >3000px";
			}
			
			//hack for bug of jpg redirects to png 
			$array = explode('.', $filename);
			$url_show = end($array);
			if ($type == 3 && $url_show == 'jpg') {
				$error_message = "flickr jpg redirected to png file";
			}
			
	} 
	
	return $error_message;
}

?> 
