<?php 

/*
	given photo_id, returns photo_stamp name 
	$photo_stamp = getPhotostamp($photo_id);
	Exmaple, given photo_id 106/POS/TRN/20161231101456-980120-256.jpg 
	this returns 20161202040727-129856
*/

function getPhotostamp($photo_id) {
	
	$pos1 = 1+strrpos($photo_id , '/'); 
	$pos2 = strrpos($photo_id , '-' );
	$length = abs($pos1 - $pos2);
	$photo_stamp = substr($photo_id, $pos1, $length);
	
	return $photo_stamp;
}

?> 
