<?php

/*
	Used for objectedit.html to add an image thumbnail
*/

$object_id = $_POST['object_id'];

// get $s3Client
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/s3connect.php");
   	  
// conncec to the database
include '../ssi/db_mysqli.php'; 

$server = 'https://s3-us-west-1.amazonaws.com/rai-objects/';
$bucket = 'rai-objects';   
$folder = $object_id.'/POS/TRN/';

// get first image from S3
// get the paths 
$response = $s3Client->listObjects(array(
	'Bucket' => $bucket, 
	'MaxKeys' => 1, 
	'Prefix' => $folder
));

$count = count($response);

// hack - I'm not sure yet how to count a bucket/folder in S3
// it seems an empty folder returns 7 

if ($count > 7) {
	$files = $response->getPath('Contents');
	$request_id = array();
	foreach ($files as $file) {
   	 	
   	 	// the image on S3
   	 	$photo_id = $file['Key'];
   	 	$urlname = $server.$photo_id;

   	 	echo $urlname;
   	 	echo '<br>';
   	 	echo $object_id;

   	 	// copy it to local folder 
   	 	copy($urlname, '../s3store/images/'.$object_id.'.jpg');
	}
} 
		
?>