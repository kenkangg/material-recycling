<?php 

/*
	Outputs a JSON from task table 
*/

require('../ssi/db_mysqli.php'); 

$task_id = $_POST['task_id'];

$taskArray = array();

$sql="SELECT * from task where task_id = '$task_id'";
$rs=$conn->query($sql);

while($row = $rs->fetch_array(MYSQL_ASSOC)) {
	$taskArray[] = $row;
}

/*
foreach ($taskArray as $key => $value) {
	$taskArray[$key]['task'] = html_entity_decode($taskArray[$key]['task']);
}
*/

echo json_encode($taskArray);

?>
