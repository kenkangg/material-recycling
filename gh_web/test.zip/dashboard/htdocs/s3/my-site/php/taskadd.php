<?php 

require('../ssi/db_mysqli.php'); 

$priority = $_POST["priority"];
$date_task = date("Ymd"); 
$task = htmlentities($_POST["task"], ENT_QUOTES, 'UTF-8');

$sql="INSERT INTO task (task_id, date_task, priority, task) VALUES ('', '$date_task', '$priority', '$task')";
$conn->query($sql); 

?>
