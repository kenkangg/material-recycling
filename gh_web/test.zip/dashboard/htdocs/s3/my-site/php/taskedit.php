<?php
/*
	update task from taskedit.html
*/

require('../ssi/db_mysqli.php'); 

$task_id = $_POST['task_id'];
$priority = $_POST["priority"];
$date_task = date("Ymd"); 
$task = htmlentities($_POST["task"], ENT_QUOTES, 'UTF-8');

$sql="UPDATE task SET 
priority = '$priority',
date_task = '$date_task',
task = '$task'
WHERE task_id = '$task_id'";
$conn->query($sql); 

?>

