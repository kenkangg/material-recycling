<?php 

/*
	ouputs <options> for pulldown form 
*/

require('../ssi/db_mysqli.php'); 


$sql="SELECT DISTINCT(bin) as bin from object ORDER BY bin asc";
$rs=$conn->query($sql);
while ($row = $rs->fetch_object()) { 
	$bin = $row->bin;
	if ($bin != '') {
		echo '<option value="'.$bin.'">'.$bin.'</option>';
	}
}

?>
