<?php 
session_start();
$password = $_POST['password'];

if ($password == 'rai') {
	$_SESSION['check']='login';
	echo $_SESSION['check']; 
} else {
	echo 'password not correct';
}


?>
