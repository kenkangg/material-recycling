<?php

/* 
	Get size of rai-objects bucket
*/

// get $s3Client
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/s3connect.php");

$result = $s3Client->listBuckets();
foreach ($result['Buckets'] as $bucket) {
    echo '<h3>'.$bucket['Name'].'</h3>'.' created on '.$bucket['CreationDate'];
}

?>



