<?php 

/* 
	Resizes jpg image at 90% resolution 
	$newcopy is the url path of the resized file 
	Min side should be 256px
	
*/

function ak_img_resize($target, $newcopy, $w, $h, $ext) {
    list($w_orig, $h_orig) = getimagesize($target);
    
    if ($w_orig > $h_orig) {
        $w = $h * ($w_orig/$h_orig);
    } else {
        $h = $w * ($h_orig/$w_orig);
    }
    
    $img = "";
    $ext = strtolower($ext);
    $img = imagecreatefromjpeg($target);
	// if(!$img) { die("getRisized.php error: bad JPEG"); } 
    $tci = imagecreatetruecolor($w, $h);
    imagecopyresampled($tci, $img, 0, 0, 0, 0, $w, $h, $w_orig, $h_orig);
	// 90% resolution 
	imagejpeg($tci, $newcopy, 90);

}


?> 
