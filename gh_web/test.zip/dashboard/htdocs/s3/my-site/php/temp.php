
<?php 


// match is succuessful 
require('../ssi/db_mysqli.php'); 
$thedate = date("Y-m-d");
echo $thedate;
$result = $conn->query("SELECT * FROM metric WHERE thedate = '$thedate'");
if($result->num_rows == 0) {
	// first entry of this date 
	echo 'new filepro_rowcount(oid)';
	$sql="INSERT INTO metric (metric_id, thedate, gridtag_keep, gridtag_notkeep) 
    VALUES ('', '$thedate', 1, 0)";
    $conn->query($sql); 

} else {
	echo 'add to';
	// add to gridtag_keep
    $sql = "UPDATE metric SET gridtag_keep = gridtag_keep + 1 WHERE thedate = '$thedate'";
    $conn->query($sql); 
}
$conn->close();



?>


