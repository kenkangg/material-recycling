<?php

/*
	output object description given the object_id
*/

require('../ssi/db_mysqli.php'); 

$object_id = $_GET['object_id'];

$sql="SELECT * from object where object_id = '$object_id'";
$rs=$conn->query($sql);
while($row = $rs->fetch_array(MYSQL_ASSOC)) {
	$bin = $row['bin'];
	$material = $row['material'];
	$object_type = $row['object_type'];
	$level1 = $row['level1'];
	$level2 = $row['level2'];
	$level3 = $row['level3'];
	$level4 = $row['level4'];
	$sku = $row['sku'];
}

echo $object_id.' - '.$bin.' '.$material.' '.$object_type.' '.$level1.' '.$level2.' '.$level3.' '.$level4.' '.$sku.' ';

?>