<?php 

/* 
	upload images to S3 from json_string.json file 
*/

$filename = $_POST['filename']; 
$object_id = $_POST['object_id']; 
$bucket = 'rai-objects';
$error_message = 'none';

// make sure object_id was received 
if (!$object_id) {
	$error_message = 'rai error: no object_id post detected';
    exit();
}

// include functions used
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/getS3upload.php");
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/getPhotoerror.php");
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/getJPGpng.php");
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/getResized.php");

// check for basic photo errors
$error_message = getPhotoerror($filename);

// no error (jpg or png, it is rights shape and size)
if ($error_message == 'none') {

	list($width, $height, $type) = getimagesize($filename); 
	$extension = 'jpg';

	// if jpg copy the image to s3store
	// tmp_file is at /dashboard/s3store/copyjpg.jpg
	if ($type == 2) {
		$tmp_file = '../s3store/copyjpg.jpg';
		if(!@copy($filename, $tmp_file)) {
			$error_message = 'unable to copy image';
		}
	}
	
	// if it is a PNG, convert to JPG 
	// tmp_file is at /dashboard/s3store/convpng.jpg
	if ($type == 3) {
		$tmp_file = getJPGpng($filename);
	}
	
	// image looks ok, upload it to S3 
	if ($type == 2 || $type == 3) {
		$error_message = getS3upload($bucket, $tmp_file, $object_id, $width, $height, $extension);
	} else {
		$error_message = 'image is neither PNG or JPG';	
	}
	
}

// output to json_engine page 
if ($error_message == 'none' ) {
	echo 'sweet pickles';
} else {
	echo 'gp upload_json.php error : '.$error_message;		
}



?> 
