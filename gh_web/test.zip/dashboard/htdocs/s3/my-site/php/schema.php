<?php
/*
	outputs the schmea of the rai database 
*/

	// connect to database
	$DBServer = '192.95.31.34'; 
	$DBUser   = 'rai';
	$DBPass   = 'Apricot1olo!';
	$DBName   = 'raiobjects';
	$conn = new mysqli($DBServer, $DBUser, $DBPass, $DBName);
	if ($conn->connect_error) {
	  trigger_error('Database connection failed: '  . $conn->connect_error, E_USER_ERROR);
	  echo "error"; 
	} 
	
	// get table names
	$sql= "SHOW TABLES";
	if(mysqli_real_query($conn, $sql)) {
		$result1 = mysqli_store_result($conn);
		while($row1 = mysqli_fetch_assoc($result1)) {
			foreach($row1 as $tableName => $tableValue) {
				echo '<h2>'.$tableValue.'</h2>';
				// get the table information 
				$sql1 = "SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE, CHARACTER_MAXIMUM_LENGTH, NUMERIC_PRECISION
				FROM INFORMATION_SCHEMA.COLUMNS
				WHERE table_name='$tableValue' AND table_schema='raiobjects'";
				
				if(mysqli_real_query($conn, $sql1)) {
					$result = mysqli_store_result($conn);
					// output data in a table format 
					echo '<table>';
					echo '<tr><th>COLUMN_NAME</th><th>DATA_TYPE</th><th>IS_NULLABLE</th><th>LENGTH</th><th>NUMERIC_PRECISION</th></tr>';

					while($row3 = mysqli_fetch_assoc($result)) {
						echo '<tr>';
						foreach($row3 as $_colName => $_colValue) {
							$_colValue = ltrim($_colValue, '-');
							echo "<td>".$_colValue."</td>";
						}
						echo "</tr>";
					}


					echo '</table>';
					mysqli_free_result($result);
				}
				else {
				printf("Query execution failed! %s", mysqli_error($conn));
				}
			}
		}
	} 

?>
