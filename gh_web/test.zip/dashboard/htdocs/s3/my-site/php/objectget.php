<?php 

/*
	Outputs a JSON from object table 
*/

require('../ssi/db_mysqli.php'); 

$object_id = $_GET['object_id'];

$objectArray = array();

$sql="SELECT * from object where object_id = '$object_id'";
$rs=$conn->query($sql);

while($row = $rs->fetch_array(MYSQL_ASSOC)) {
	$objectArray[] = $row;
}

echo json_encode($objectArray);

?>
