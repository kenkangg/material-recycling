<?php

/*
	delete a SPT image pair from S3 from speedtag.html
	photo_stamp example 20161227044847-487912
*/

// get the photo_stamp
$photo_stamp = $_POST['photo_stamp'];

$prefix1 = '0/SPT/TRN/'.$photo_stamp;
$prefix2 = '0/SPT/ORG/'.$photo_stamp;

// connect to S3 bucket to get client
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/s3connect.php");
$bucket = 'rai-objects';

// delete the TRN image
$s3Client->deleteMatchingObjects($bucket, $prefix1);
	
// delete the ORG image 
$s3Client->deleteMatchingObjects($bucket, $prefix2);

?>

