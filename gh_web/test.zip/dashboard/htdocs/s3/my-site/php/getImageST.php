<?php

/* 
	Get first image in 0 Speedtag folder 
*/

// get $s3Client
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/s3connect.php");

// function to convert long photo_id to photo_stamp
include($_SERVER['DOCUMENT_ROOT']."/dashboard/php/getPhotostamp.php");

// get the paths 
$server = 'https://s3-us-west-1.amazonaws.com/rai-objects/';
$bucket = 'rai-objects';
$folder = '0/SPT/ORG/';

$iterator = $s3Client->getIterator('ListObjects', array(
    'Bucket' => 'rai-objects',
    'Prefix' => $folder
));

foreach ($iterator as $object) {
	
	$photo_id = $object['Key'];

	// get the Photoset
	$photo_stamp = getPhotostamp($photo_id);
	
	// show image 
	echo 'https://s3-us-west-1.amazonaws.com/rai-objects/'.$photo_id;

	break;

}





