<?php 

require('../ssi/db_mysqli.php'); 


$json_string = '[';
$keep_sum = 0;
$notkeep_sum =0;
$sql="SELECT * from metric ORDER BY thedate asc";
$rs=$conn->query($sql);
while($row = $rs->fetch_assoc()) {
	$thedate = $row["thedate"];
	$gridtag_keep = $row["gridtag_keep"];
	$gridtag_notkeep = $row["gridtag_notkeep"];
	
	$keep_sum = $keep_sum + $gridtag_keep;
	$notkeep_sum = $notkeep_sum + $gridtag_notkeep;
	$total = $keep_sum + $notkeep_sum;
	$percent_accuracy = round((100 * ($keep_sum/$total)), 2);

	$json_string .= '{"date":"'.$thedate.'","accuracy":"'.$percent_accuracy.'"},';

}

$json_string = rtrim($json_string, ',');
$json_string .= ']';
echo $json_string;
$conn->close();

?>
