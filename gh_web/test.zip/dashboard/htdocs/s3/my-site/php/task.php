<?php 
/*
	Outputs json array for task.html dataTable
*/

require('../ssi/db_mysqli.php'); 

$taskArray = array();
$sql="SELECT * from task";
$rs=$conn->query($sql);
while($row = $rs->fetch_array(MYSQL_ASSOC)) {
	$taskArray[] = $row;
}
// add the data heaader for dataTables 
echo '{ "data": '.json_encode($taskArray).'}';


?>
