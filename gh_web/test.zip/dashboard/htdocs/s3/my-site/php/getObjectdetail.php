<?php

/*
	Given an object_id, return the object description
*/
   
$object_id = $_POST['object_id'];
	   
include '../ssi/db_mysqli.php';    

$sql="SELECT * from object where object_id = '$object_id'";
$rs=$conn->query($sql);
while($row = $rs->fetch_assoc()) {
	$bin = $row["bin"];	
	$material = $row["material"];
	$object_type = $row["object_type"];
	$level1 = $row["level1"];	
	$level2 = $row["level2"];	
	$level3 = $row["level3"];	
	$level4 = $row["level4"];	
	$sku = $row["sku"];	
}

$objectdetail = $object_id.' '.$material.' '.$object_type.' '.$level1.' '.$level2.' '.$level3.' '.$level4.' '.$sku;
echo $objectdetail;   
		
?>