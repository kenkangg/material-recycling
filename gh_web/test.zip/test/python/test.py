#!/usr/bin/env python



print "Content-type: text/html\n\n"
print "<html>Hello world!</html>"

i = 1
print i

