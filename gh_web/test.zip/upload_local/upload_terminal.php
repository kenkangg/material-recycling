<?php 

/*
		Uploads images directly to S3, both original size, and 256px
		Must specify correct object_id first 

		Steps:  
		(1) Change object_id to correct GET object_id in Terminal 
		(2) Put images in /localstore (960px, check orientation)
		(3) Run "php upload_terminal.php" in the /local directory
		(4) Loops through 100 images 

*/

$object_id = 156;
$bucket= 'rai-objects';

// connect to database
include '/Users/geraldp/gdrive/recycle_ai/dev_web/dashboard/ssi/db_mysqli.php';

// from the database, get the object description 
$sql="SELECT * from object where object_id = '$object_id'";
$rs=$conn->query($sql);
while($row = $rs->fetch_array(MYSQL_ASSOC)) {
	$bin = $row["bin"];	
	$material = $row["material"];
	$object_type = $row["object_type"];	
	$level1 = $row["level1"];	
	$level2 = $row["level2"];	
	$level3 = $row["level3"];	
	$level4 = $row["level4"];	
	$sku = $row["sku"];	
} 
$objectdesc = $object_id.' '.$bin.' '.$material.' '.$object_type.' '.$level1.' '.$level2.' '.$level3.' '.$level4.' '.$sku;

// start a count
$i = 0; 

// get the local directory and filename 
$currentdirectory = getcwd();
$photodirectory = $currentdirectory.'/localstore';
$files = scandir($photodirectory);

// do the S3 stuff 
include '/Users/geraldp/gdrive/recycle_ai/dev_web/vendor/autoload.php';
use Aws\S3\S3Client;
use Aws\S3\Exception\S3Exception;

$s3Client = new S3Client([
    'version'     => 'latest',
    'region'      => 'us-west-1',
    'credentials' => [
        'key'    => 'AKIAIU6EYHUUYOI5RCBA',
        'secret' => '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'
    ],
]);

foreach( new DirectoryIterator($photodirectory) as $file) {
    if( $file->isFile() === TRUE && $file->getBasename() !== '.DS_Store') {

    	// loop through photos in the /localstore folder 

    	$sourcefilename = htmlentities($file->getBasename());
    	$sourcefile = $photodirectory.'/'.$sourcefilename; 
    	

	    // get the width and height of the original photo 
		list($width, $height, $type) = getimagesize($sourcefile);
		$maxdim = max($width, $height);

		// make the new file names for S3
		date_default_timezone_set('America/Los_Angeles'); 
		$photo_stamp = date("Ymdhis").'-'.rand(100000,999999);
		
		$keynameorg = $object_id.'/POS/ORG/'.$photo_stamp.'-'.$maxdim.'.jpg';		

		// upload the orginal to S3
		try {
			$result = $s3Client->putObject(array(
				'Bucket' => $bucket,
				'Key'    => $keynameorg,
				'SourceFile'   => $sourcefile,
				'StorageClass' => 'REDUCED_REDUNDANCY',
				'ACL'    => 'public-read'
			));
			} catch (S3Exception $e) {
				$error_message = $e->getMessage() . "\n";
		}

		// resize the original file to 256 min per side 
		$sourcefile256 = $photodirectory.'/copytemp256.jpg';
		$keyname256 = $object_id.'/POS/TRN/'.$photo_stamp.'-256.jpg';

		$w = 256; 
		$h = 256;
		if ($width > $height) {
		    $w = 256 * ($width/$height);
		} else {
		    $h = 256 * ($height/$width);
		}
		$img = "";
		$img = imagecreatefromjpeg($sourcefile);
		// if(!$img) { die("getRisized.php error: bad JPEG"); } 
		$tci = imagecreatetruecolor($w, $h);
		imagecopyresampled($tci, $img, 0, 0, 0, 0, $w, $h, $width, $height);
		// 90% resolution 
		imagejpeg($tci, $sourcefile256, 90);

		// upload the 256 image to S3

		try {
			$result = $s3Client->putObject(array(
				'Bucket' => $bucket,
				'Key'    => $keyname256,
				'SourceFile'   => $sourcefile256,
				'StorageClass' => 'REDUCED_REDUNDANCY',
				'ACL'    => 'public-read'
			));
			} catch (S3Exception $e) {
				$error_message = $e->getMessage() . "\n";
		}

		$i++; 
		unlink($sourcefile);
		echo $i.' '.$sourcefilename." uploaded to S3 ".$objectdesc."\n";
		
		// temporary limit uploads to 100 images x2
		if ($i == 100) {
			exit();
		}

    }
}

unlink ($sourcefile256);


?> 
