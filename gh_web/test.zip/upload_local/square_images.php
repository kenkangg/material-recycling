<?php 

/*
		Crops images that are 960x720

		$x, $y is the point from the top left to start crop
		$width and $height should be current_width - 2x, currenty-2y
*/

// get the local directory and filename 

$arr = array(19, 20, 41, 42, 43, 44, 45, 46, 47, 48, 49, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130);

foreach ($arr as $key => $value) {
    
    echo $value;

    $currentdirectory = getcwd();
	$photodirectory = $currentdirectory.'/'.$value;
	$files = scandir($photodirectory);

	$i = 0;

	foreach( new DirectoryIterator($photodirectory) as $file) {
	    if( $file->isFile() === TRUE && $file->getBasename() !== '.DS_Store') {

	    	// loop through photos in the /localstore folder 

	    	
	    	$sourcefilename = htmlentities($file->getBasename());
	    	$sourcefile = $photodirectory.'/'.$sourcefilename; 
	    	$squarefile = $photodirectory.'/square-'.$i.'.jpg'; 

			$image = imagecreatefromjpeg($sourcefile); 

			list($x, $y) = getimagesize($sourcefile);

			// horizontal rectangle
			if ($x > $y) {
			    $square = $y;              // $square: square side length
			    $offsetX = ($x - $y) / 2;  // x offset based on the rectangle
			    $offsetY = 0;              // y offset based on the rectangle
			}
			// vertical rectangle
			elseif ($y > $x) {
			    $square = $x;
			    $offsetX = 0;
			    $offsetY = ($y - $x) / 2;
			}
			// it's already a square
			else {
			    $square = $x;
			    $offsetX = $offsetY = 0;
			}

			$endSize = 256;
			$tn = imagecreatetruecolor($endSize, $endSize);
			imagecopyresampled($tn, $image, 0, 0, $offsetX, $offsetY, $endSize, $endSize, $square, $square);

			imagejpeg($tn, $squarefile, 100) ; 

			unlink($sourcefile);

			echo $value.' ';

			$i++;
	    }
	}

}

?> 
