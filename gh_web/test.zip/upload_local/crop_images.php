<?php 

/*
		Crops images that are 960x720
		This is pre-processing to upload the largest file size to S3
*/

// get the local directory and filename 
$currentdirectory = getcwd();
$photodirectory = $currentdirectory.'/localstore';
$files = scandir($photodirectory);

date_default_timezone_set('America/Los_Angeles');
$now = date("Ymdhms");  
$i = 0;

foreach( new DirectoryIterator($photodirectory) as $file) {
    if( $file->isFile() === TRUE && $file->getBasename() !== '.DS_Store') {

    	// loop through photos in the /localstore folder 

    	$sourcefilename = htmlentities($file->getBasename());
    	$sourcefile = $photodirectory.'/'.$sourcefilename; 
    	list($width, $height) = getimagesize($sourcefile);

    	$croppedfile = $photodirectory.'/cropped-'.$now.'-'.$i.'.jpg'; 

		$im = imagecreatefromjpeg($sourcefile);
		
		// $size = min(imagesx($im), imagesy($im));

		// photo from iPhone is set to 960 x 720 
		// desired square width (720, 560, 420)

		$squared = 600;


		$w = ($width-$squared)/2;
		$h = ($height-$squared)/2;
		$im2 = imagecrop($im, ['x' => $w, 'y' => $h, 'width' => $squared, 'height' => $squared]);

		if ($im2 !== FALSE) {
		    imagejpeg($im2, $croppedfile);
		}

		unlink($sourcefile);

		$i++;
    }
}

?> 
