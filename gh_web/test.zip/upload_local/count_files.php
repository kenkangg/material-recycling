<?php 

/*
		Counts the files in directory
*/




$arr = array(19, 20, 41, 42, 43, 44, 45, 46, 47, 48, 49, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130);

$currentdirectory = getcwd();


foreach ($arr as $key => $value) {

    $dir = $currentdirectory.'/'.$value;
    $fi = new FilesystemIterator($dir, FilesystemIterator::SKIP_DOTS);
    $fileCount = iterator_count($fi);

    if ($fileCount % 2 == 0) {
          // it's even
            echo "EVEN  ".$fileCount." files in dir ".$value."\n";
    } else {
            echo "ODD  ".$fileCount." files in dir ".$value."\n";
    } 

}

?> 
